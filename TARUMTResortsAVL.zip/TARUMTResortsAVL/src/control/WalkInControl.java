package control;

import adt.HashTableInterface;
import adt.ListInterface;
import adt.QueueInterface;
import adt.SearchTreeInterface;
import boundary.WalkInCLI;
import entity.Booking;
import entity.BookingStatus;
import entity.Guest;
import entity.Member;
import entity.Room;
import java.time.LocalDate;
import java.util.Iterator;
import utility.TierRankUtility;
import utility.ValidationUtility;

/**
 * WalkInControl.java - 模块1(Walk-In Registrations & Standard Booking)的业务逻辑。
 *
 * @author 某某
 *
 * 说明:
 * - 三条 Circular Linked Queue,按房型分开(Standard/Deluxe/Suite 各一条),互相独立
 * - 分房时一定要先看VIP那边的树,VIP树只要有人在等,这个房型的Walk-In一律不能分房——
 *   这是两个模块共用的关键规则:VIP永远优先
 * - 只对"会调用collection ADT方法"的操作(登记、取消)做输入校验,查看名单这种不用
 * - 分房不再是一个手动菜单动作,改成 tryAllocate() 这个检查:登记完当下会自动跑一次,
 *   之后房间从不可用变可用时(退房/清洁完成)也该跑一次——那个触发点现在还没有人会调用它
 *   (housekeeping/checkout都还没做),先把方法留成public,等那边接进来直接调用即可
 */
public class WalkInControl {

    private final WalkInCLI walkInCLI;
    private final QueueInterface<Booking> standardQueue;
    private final QueueInterface<Booking> deluxeQueue;
    private final QueueInterface<Booking> suiteQueue;
    private final SearchTreeInterface<Booking> standardVipTree;
    private final SearchTreeInterface<Booking> deluxeVipTree;
    private final SearchTreeInterface<Booking> suiteVipTree;
    private final ListInterface<Room> roomList;
    private final HashTableInterface<Guest> guestTable;
    private final ListInterface<Member> memberList;

    private int arrivalCounter;
    private int bookingCounter;
    private int confirmationCounter;
    private int memberCounter;

    public WalkInControl(WalkInCLI walkInCLI,
                          QueueInterface<Booking> standardQueue,
                          QueueInterface<Booking> deluxeQueue,
                          QueueInterface<Booking> suiteQueue,
                          SearchTreeInterface<Booking> standardVipTree,
                          SearchTreeInterface<Booking> deluxeVipTree,
                          SearchTreeInterface<Booking> suiteVipTree,
                          ListInterface<Room> roomList,
                          HashTableInterface<Guest> guestTable,
                          ListInterface<Member> memberList) {
        if (walkInCLI == null || standardQueue == null || deluxeQueue == null || suiteQueue == null
                || standardVipTree == null || deluxeVipTree == null || suiteVipTree == null
                || roomList == null || guestTable == null || memberList == null) {
            throw new IllegalArgumentException("WalkInControl dependencies cannot be null");
        }
        this.walkInCLI = walkInCLI;
        this.standardQueue = standardQueue;
        this.deluxeQueue = deluxeQueue;
        this.suiteQueue = suiteQueue;
        this.standardVipTree = standardVipTree;
        this.deluxeVipTree = deluxeVipTree;
        this.suiteVipTree = suiteVipTree;
        this.roomList = roomList;
        this.guestTable = guestTable;
        this.memberList = memberList;
        // 用20000000起跳当VIP的确认号,Walk-In从10000000起跳,避免两边号码重复
        this.arrivalCounter = 0;
        this.bookingCounter = 0;
        this.confirmationCounter = 10000000;
        // 扫一次种子会员资料(MemberDao已经在这之前把它们读进memberList了),
        // 接着种子资料的编号继续往下用,格式才会跟M1001这些一致——这个计数器从此只有
        // WalkInControl自己在用,不会再重新扫描,所以不会有两边各自算出同一个号码的风险
        this.memberCounter = computeNextMemberNumber();
    }

    /**
     * 跑这个模块自己的选单循环,直到使用者选择返回。
     */
    public void run() {
        boolean running = true;
        while (running) {
            int choice = walkInCLI.displayMenuAndGetChoice();
            switch (choice) {
                case 1:
                    doRegister();
                    break;
                case 2:
                    doCancel();
                    break;
                case 3:
                    doViewWaitingList();
                    break;
                case 0:
                    running = false;
                    break;
                default:
                    walkInCLI.displayInvalidChoice();
            }
        }
    }

    // ========== 功能1:登记新客人 ==========

    private void doRegister() {
        // 散客不是会员,直接问姓名、电话,不用像VIP那样先查会员资料
        String name = walkInCLI.promptName();
        String phone = walkInCLI.promptPhone();
        if (!ValidationUtility.isDigitsOnly(phone)) {
            walkInCLI.displayInvalidPhone(phone);
            return;
        }

        // 一位客人可能一次要订好几间房(不一定同房型),所以姓名/电话只问一次,
        // 底下用同一个confirmationNumber循环开多笔Booking,直到客人说不用再加了
        confirmationCounter++;
        String confirmationNumber = String.valueOf(confirmationCounter);

        boolean continueBooking = true;
        while (continueBooking) {
            String roomType = walkInCLI.promptRoomType();
            QueueInterface<Booking> queue = getQueueForRoomType(roomType);
            if (queue == null) {
                walkInCLI.displayInvalidRoomType(roomType);
            } else {
                // 住几晚要在客人还在面前的登记当下先问好,存进Booking——
                // 分房不再保证是当场发生的,之后可能是房间空出来才自动触发,
                // 到时候客人不一定还在,没办法临时问
                int numberOfNights = walkInCLI.promptNumberOfNights();
                if (numberOfNights <= 0) {
                    walkInCLI.displayInvalidNumberOfNights(numberOfNights);
                } else {
                    arrivalCounter++;
                    bookingCounter++;
                    String bookingId = "WB" + String.format("%06d", bookingCounter);

                    // memberId是null、tierRank是0——散客没有等级,这两个字段跟VIP那边刻意留空/最低
                    Booking booking = new Booking(bookingId, confirmationNumber, name, phone, null,
                            roomType, BookingStatus.PENDING, "WALK_IN", arrivalCounter, 0);
                    booking.setNumberOfNights(numberOfNights);

                    queue.enqueue(booking);
                    walkInCLI.displayRegistrationResult(booking);

                    // 登记完立刻检查一次这个房型能不能马上分房(VIP没人等、队伍轮到他、有空房)
                    tryAllocate(roomType);
                }
            }
            continueBooking = walkInCLI.promptAddAnotherRoom();
        }
    }

    // ========== 分房检查(不再是手动菜单动作) ==========

    /**
     * 检查指定房型现在能不能分房,能就把队头那笔Booking分掉。
     * 两个触发时机:1) doRegister() 登记完当下跑一次;2) 之后房间从不可用变可用时
     * (退房/清洁完成,housekeeping/checkout模块接上后)也该跑一次——目前还没有人调用
     * 第2种情况,方法先留成public,等那边接进来直接调用。
     * 什么都不满足就静静地什么都不做(客人留在队伍里继续等),不当错误处理。
     */
    public void tryAllocate(String roomType) {
        QueueInterface<Booking> queue = getQueueForRoomType(roomType);
        SearchTreeInterface<Booking> vipTree = getVipTreeForRoomType(roomType);
        if (queue == null || vipTree == null) {
            return;
        }

        // 关键规则:VIP永远优先——只要这个房型的VIP树还有人在等,
        // Walk-In这边完全不动,不管Walk-In已经排了多久
        if (!vipTree.isEmpty()) {
            return;
        }

        if (queue.isEmpty()) {
            return;
        }

        Room availableRoom = findAvailableRoom(roomType);
        if (availableRoom == null) {
            return;
        }

        // 先peek队头,不要马上dequeue——要等确定真的有空房可以分,才正式把它从队伍拿掉
        Booking frontBooking = queue.getFront();

        LocalDate checkIn = LocalDate.now();
        LocalDate checkOut = checkIn.plusDays(frontBooking.getNumberOfNights());

        frontBooking.setStatus(BookingStatus.CHECKED_IN);
        frontBooking.setAssignedRoomNo(availableRoom.getRoomNumber());
        availableRoom.setStatus("OCCUPIED");
        // 现在才真正把它从队伍拿掉,因为确定分房成功了
        queue.dequeue();

        // 同一位客人(同一个confirmationNumber)可能早就因为前一间房分房成功,
        // 已经在guestTable里有Guest记录了——这时候不能再new一个塞进去(那样guestTable
        // 里会出现两个confirmationNumber相同的Guest,查找时后者会盖住前者),
        // 而是要把这间新房加进原本那个Guest的bookedRooms
        Guest guest = findGuestByConfirmationNumber(frontBooking.getConfirmationNumber());
        if (guest == null) {
            // Walk-In一走进这个分支,就代表他是"这辈子第一次被系统看到"的人(还没有
            // memberId)——一旦真的入住(不是还在排队),就自动帮他开一个最低等级的
            // Member。tier用"Standard",TierRankUtility.tierToRank()对认不得的tier
            // 一律回传0,所以不会因为多了memberId就意外插进VIP优先级队伍。
            // 下次这个人再来,理论上会自称会员、直接走VIP模块用memberId登记,
            // 不会再经过这里,所以这里不用查重。
            Member newMember = enrollAsStandardMember(frontBooking.getGuestNameSnapshot(),
                    frontBooking.getPhoneSnapshot());

            guest = new Guest(frontBooking.getConfirmationNumber(), frontBooking.getGuestNameSnapshot(),
                    frontBooking.getPhoneSnapshot(), newMember.getMemberId(), newMember.getTier(),
                    checkIn.toString() + " " + java.time.LocalTime.now().withNano(0).toString(),
                    checkIn.toString(), checkOut.toString(), frontBooking.getNumberOfNights());
            guestTable.add(guest);
        }
        guest.addRoom(availableRoom.getRoomNumber());

        // Record the stay period on the booking itself and link it to the guest,
        // so the Front-Desk module can list every booking under one
        // confirmation number with its own dates.
        frontBooking.setStayPeriod(checkIn.toString(), checkOut.toString(), frontBooking.getNumberOfNights());
        guest.addBooking(frontBooking);

        // 分房那一刻就先给客人看一下预估房费(等级折扣是"个性化促销"的一种,只影响
        // 价格显示,不碰房型/房间状态)——Walk-In新客人tier固定是Standard(0%折扣),
        // 正式结算金额还是要等退房才真正定案
        double originalPrice = availableRoom.getNightlyRate() * frontBooking.getNumberOfNights();
        int discountPercent = TierRankUtility.tierToDiscountPercent(guest.getTier());
        double finalPrice = originalPrice - (originalPrice * discountPercent / 100.0);

        walkInCLI.displayAllocationResult(frontBooking, availableRoom, originalPrice, discountPercent, finalPrice);
    }

    // ========== 功能3:取消排队 ==========

    private void doCancel() {
        String roomType = walkInCLI.promptRoomType();
        QueueInterface<Booking> queue = getQueueForRoomType(roomType);
        if (queue == null) {
            walkInCLI.displayInvalidRoomType(roomType);
            return;
        }

        // 用bookingId取消,不是confirmationNumber——同一个confirmationNumber可能同时
        // 有好几笔Booking在同一个房型的队伍里(一次订多间房),用confirmationNumber去找
        // 只会抓到排最前面那一笔,没办法让客人指定要取消的到底是哪一间;bookingId每笔
        // 都是唯一的,不会有这个歧义
        String bookingId = walkInCLI.promptBookingIdToCancel();
        if (ValidationUtility.isBlank(bookingId)) {
            walkInCLI.displayInvalidBookingId(bookingId);
            return;
        }
        Booking target = findBookingInQueue(queue, bookingId);
        if (target == null) {
            walkInCLI.displayCancelResult(false);
            return;
        }

        target.setStatus(BookingStatus.CANCELLED);
        // 普通enqueue/dequeue只能动队头/队尾,取消要用QueueInterface额外写的remove()
        // 才能真正把队伍中间那一笔完全移除,不是只改状态
        queue.remove(target);
        walkInCLI.displayCancelResult(true);
    }

    // ========== 功能4:查看排队名单 ==========

    private void doViewWaitingList() {
        String roomType = walkInCLI.promptRoomType();
        QueueInterface<Booking> queue = getQueueForRoomType(roomType);
        if (queue == null) {
            walkInCLI.displayInvalidRoomType(roomType);
            return;
        }

        walkInCLI.displayWaitingList(roomType, queue.getIterator());
    }

    // ========== 内部辅助方法 ==========

    private QueueInterface<Booking> getQueueForRoomType(String roomType) {
        if (roomType == null) {
            return null;
        }
        switch (roomType.trim()) {
            case "Standard":
                return standardQueue;
            case "Deluxe":
                return deluxeQueue;
            case "Suite":
                return suiteQueue;
            default:
                return null;
        }
    }

    private SearchTreeInterface<Booking> getVipTreeForRoomType(String roomType) {
        if (roomType == null) {
            return null;
        }
        switch (roomType.trim()) {
            case "Standard":
                return standardVipTree;
            case "Deluxe":
                return deluxeVipTree;
            case "Suite":
                return suiteVipTree;
            default:
                return null;
        }
    }

    /**
     * 在roomList里找第一间"房型对得上、状态严格等于AVAILABLE"的房间。
     * 一定要用 equals("AVAILABLE"),不能只判断"不是OCCUPIED"——
     * 因为OUT_OF_ORDER的房间也"不是OCCUPIED",但不该被分配出去。
     */
    private Room findAvailableRoom(String roomType) {
        Iterator<Room> iterator = roomList.getIterator();
        while (iterator.hasNext()) {
            Room room = iterator.next();
            if (room.getRoomType().equals(roomType) && room.getStatus().equals("AVAILABLE")) {
                return room;
            }
        }
        return null;
    }

    /**
     * 帮一位第一次入住、还不是会员的Walk-In客人,开一个最低等级(Standard)的会员档案,
     * 存进memberList,再回传这个新Member给呼叫方拿memberId/tier去建Guest用。
     * currentPoints/totalPointsEarned都从0开始——实际赚多少分是模块5的事,这里只负责
     * "这个人现在是有memberId的会员了"这个身份的建立。
     */
    private Member enrollAsStandardMember(String name, String phone) {
        String memberId = "M" + memberCounter;
        memberCounter++;
        Member member = new Member(memberId, name, phone, "Standard", 0, 0);
        memberList.add(member);
        return member;
    }

    /**
     * 扫一次memberList,把"M"开头、后面接数字的会员编号(比如种子资料的M1001~M1005)
     * 都解析出数字部分,取最大值+1,当作WalkInControl自己接下来要用的编号起点——
     * 之后终生只有这个计数器在用这个号码段,不会再重新扫描,新会员编号才会跟种子资料
     * 格式一致,同时不会有"两个地方各自算出同一个号码"这种撞号风险。
     * memberList万一是空的(理论上不会,MemberDao已经先读过种子资料),给一个保底起点。
     */
    private int computeNextMemberNumber() {
        int maxNumber = 1000;
        Iterator<Member> iterator = memberList.getIterator();
        while (iterator.hasNext()) {
            Member member = iterator.next();
            String id = member.getMemberId();
            if (id != null && id.length() > 1 && id.charAt(0) == 'M') {
                try {
                    int number = Integer.parseInt(id.substring(1));
                    if (number > maxNumber) {
                        maxNumber = number;
                    }
                } catch (NumberFormatException e) {
                    // ID不是"M"+纯数字这个格式,跳过,不影响其他笔的计算
                }
            }
        }
        return maxNumber + 1;
    }

    /**
     * 用confirmationNumber去guestTable里查这位客人是否已经有Guest记录
     * (比如已经因为另一间房分房成功而建过了)。
     * Guest的equals()/hashCode()只看confirmationNumber,所以拿一个
     * 只填了confirmationNumber、其他栏位留null的样板去查,一样能正确命中。
     */
    private Guest findGuestByConfirmationNumber(String confirmationNumber) {
        Guest template = new Guest(confirmationNumber, null, null, null, null, null, null, null, 0);
        return guestTable.getEntry(template);
    }

    /**
     * 在指定的队伍里,用bookingId线性找出对应的Booking物件。
     * 找到的是"真正存在队伍里的那个物件",这样才能拿去交给 queue.remove() 正确比对、移除。
     */
    private Booking findBookingInQueue(QueueInterface<Booking> queue, String bookingId) {
        Iterator<Booking> iterator = queue.getIterator();
        while (iterator.hasNext()) {
            Booking booking = iterator.next();
            if (booking.getBookingId().equals(bookingId)) {
                return booking;
            }
        }
        return null;
    }
}
