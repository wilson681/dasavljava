package control;

import adt.HashTableInterface;
import boundary.FrontDeskCLI;
import entity.Guest;

/**
 * Control for the Front-Desk Service module.
 */
public class FrontDeskControl {

    private FrontDeskCLI frontDeskCLI;
    private HashTableInterface<Guest> guestTable;
    
    public FrontDeskControl(
        FrontDeskCLI frontDeskCLI,
        HashTableInterface<Guest> guestTable) {

        this.frontDeskCLI = frontDeskCLI;
        this.guestTable = guestTable;
    }

    public void run() {

        boolean running = true;

        while (running) {

            int choice = frontDeskCLI.displayMenuAndGetChoice();

            switch (choice) {

                case 1:
                    searchGuestByConfirmationNumber();
                    break;

                case 2:
                    System.out.println("Room Availability - coming soon.");
                    break;

                case 3:
                    System.out.println("Billing Details - coming soon.");
                    break;

                case 0:
                    running = false;
                    break;

                default:
                    frontDeskCLI.displayInvalidChoice();
                    break;
            }
        }
    }
    
    private void searchGuestByConfirmationNumber() {

    String confirmationNumber =
            frontDeskCLI.promptConfirmationNumber();

    Guest searchKey = new Guest(confirmationNumber);

    Guest foundGuest = guestTable.getEntry(searchKey);

    if (foundGuest == null) {
        frontDeskCLI.displayGuestNotFound();
    } else {
        frontDeskCLI.displayGuestDetails(
                foundGuest.getConfirmationNumber(),
                foundGuest.getName(),
                foundGuest.getPhone(),
                foundGuest.getMemberId(),
                foundGuest.getTier()
        );
    }
}
    
}