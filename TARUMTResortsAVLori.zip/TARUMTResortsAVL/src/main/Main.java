package main;

/**
 * 程序唯一入口。基础架构阶段还没有正式 module，
 * 所以这里只是 placeholder；AVL 的验证方式是 scripts/test.sh。
 *
 * <p>为什么 Main 什么都不做：ECB 规定 Main 只负责「组装并启动顶层 Control」，
 * 菜单、Scanner、业务规则、ADT 操作全都不属于这里。
 * 团队整合时把 main 改成 {@code new MainMenuControl().run();}，
 * 共享 tree 在那个 composition root 建立并注入各 module Control。</p>
 *
 * @author TODO：提交前替换成实际负责组员姓名
 */
public class Main {

    // private constructor：这个 class 只有 static 入口，
    // 不应该被 new，把 constructor 藏起来防止误用。
    private Main() {
    }

    /**
     * 暂时只提示验证方式；整合后启动顶层 Control。
     *
     * @param args 未使用
     */
    public static void main(String[] args) {
        // 现在还没有菜单可以启动，先印出「这个阶段该怎么验证」的提示，
        // 避免有人 run 了以为程序坏掉。
        System.out.println("TARUMT Resorts - AVL foundation.");
        System.out.println("Run ./scripts/test.sh to verify the AVL ADT.");
        // 之后整合时换成这一行（Main 保持一行启动，别的都不加）：
        // new MainMenuControl().run();
    }
}
